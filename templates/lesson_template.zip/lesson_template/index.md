---
home: true
heroImage:  /assets/word-logo.png
tagline: Introduction to Python
actionText: Get Started!
actionLink: /intro
features:
- title: Feature 1 Title
  details: Feature 1 Description
- title: Feature 2 Title
  details: Feature 2 Description
- title: Feature 3 Title
  details: Feature 3 Description
footer: Made by The LEAGUE with ❤️
---

This is the index page for the lesson website. 
