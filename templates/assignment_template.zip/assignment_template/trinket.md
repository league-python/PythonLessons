# Shapes and Colors

{{ goal_image("goal.png") }}

In this lesson, we will teach the turtle to draw shapes and colors. Here is 
what your turtle will be able to do by the end of this lesson:

# Assignment

Read each of  the comments in the code carefully for instructions. 

{{ trinket("shapes_and_colors.py", width="100%", height="600", embed_type="python") | safe }}

Have fun!